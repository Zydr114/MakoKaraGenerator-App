"""One-time source/binary/process audit in the original research workspace.

Use analyze.py to recompute the archived statistics without a build or GPU.
This script deliberately requires the original source copies and binaries.
"""
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
repo = root.parents[1]
def read(path):
    return json.loads(path.read_text())
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

inputs = read(root / 'runtime-inputs.json')['files']
for row in inputs:
    assert sha(repo / row['path']) == row['baselineSha256'], row['path']
    for variant, expected in row['variants'].items():
        assert sha(root / ('source-' + variant) / row['path']) == expected, (variant, row['path'])
changes = {variant: [r['path'] for r in inputs if r['baselineSha256'] != r['variants'][variant]]
           for variant in ['top-left', 'matched-read']}
assert all(paths == ['src/MakoKaraGenerator.Rendering.Skia/SkiaRenderBackend.cs'] for paths in changes.values())
for name in ['runtime-prepare.json', 'runtime-matched-prepare.json']:
    data = read(root / name)
    patch = 'top-left-only.patch' if name == 'runtime-prepare.json' else 'matched-read-only.patch'
    assert sha(root / patch) == data['patchSha256']

subprocess.run(['git', 'diff', '--exit-code', 'HEAD', '--', 'src', 'tests', 'samples',
                'tools/backend-render-performance', 'Directory.Build.props', 'Directory.Packages.props', 'global.json'],
               cwd=repo, check=True, stdout=subprocess.PIPE)

observed = []
runtime = []
baseline_dll = repo / 'artifacts/performance-optimization-20261027-ab-resumed/sources/new/tools/backend-render-performance/Runner/bin/Release/net10.0/MakoKaraGenerator.Rendering.Skia.dll'
micro_records = micro_surfaces = 0
for label in ['runs', 'color-runs', 'origin-runs', 'runtime-runs', 'followup-runs']:
    for job in read(root / label / 'manifest.json'):
        assert job['exitCode'] == 0
        if label in ['runs', 'color-runs', 'origin-runs']:
            path = root / label / f"r{job['round']}-{job['backend']}.json"
            data = read(path)
            assert data['assemblySha256'] == sha(baseline_dll)
            assert data['mismatches'] == 0
            pid = data['processId']
            micro_records += len(data['records'])
            micro_surfaces += data['surfaces']
        else:
            command = job['command']
            data = read(Path(command[command.index('--output') + 1]))
            dll = Path(command[1])
            assert sha(dll) == job['runnerSha256']
            assert sha(dll.parent / 'MakoKaraGenerator.Rendering.Skia.dll') == job['renderingSha256']
            pid = job['pid']
            assert pid == data['process']['pid']
            assert 'libvulkan_radeon.so' in data['process']['mappedLibraries']
            assert data['process']['drmDevices']
            assert data['deviceProbe']['backend'] == 'vulkan'
            assert not data['traceAvailable']
            assert not any(f['hasError'] for f in data['frames'])
            runtime.append(data)
        assert not Path(f'/proc/{pid}').exists(), pid
        observed.append({'pid': pid, 'group': label, 'exitCode': 0, 'pidAbsentAtAudit': True})

for row in read(root / 'upstream/manifest.json') + read(root / 'upstream/provenance.json'):
    assert sha(root / 'upstream' / row['local']) == row['sha256']
for row in read(root / 'assessment.json')['historicalTraceReanalysis']:
    assert sha(root / row['source']) == row['sha256']
assessment = read(root / 'assessment.json')
pairs = [p for group in assessment['runtime'].values() for p in group['pairs']]
matched = [f for p in pairs if 'matched-read' in p['candidate'] for f in p['frames']]
origin = [f for p in pairs if 'top-left' in p['candidate'] for f in p['frames']]
assert len(matched) == 161 and all(f['pixelEqual'] and f['diagnosticEqual'] for f in matched)
assert len(origin) == 20 and sum(not f['pixelEqual'] for f in origin) == 5
assert all(f['diagnosticEqual'] for f in origin)
result = {
    'schema': 'gpu-structural-research-audit-v1',
    'auditedUtc': datetime.now(timezone.utc).isoformat(),
    'sourceCommit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(),
    'selectedInputsVerified': len(inputs), 'variantDifferences': changes,
    'productionAndBenchmarkTrackedDiffEmpty': True,
    'micro': {'processes': 15, 'readRecords': micro_records, 'surfaces': micro_surfaces,
              'sameMethodGroupMismatches': 0, 'crossOriginPixelHashMismatches': 192},
    'runtime': {'processes': len(runtime), 'projectFrames': sum(d['projectFrameCount'] for d in runtime),
                'probeFrames': sum(d['deviceProbeFrames'] for d in runtime),
                'maximumProjectFramesPerProcess': max(d['projectFrameCount'] for d in runtime),
                'matchedReadFramePairs': len(matched), 'matchedReadAllPixelAndDiagnosticEqual': True,
                'topLeftFramePairs': len(origin), 'topLeftUnequalPixelPairs': 5,
                'radVAndDrmEvidenceProcesses': len(runtime)},
    'observedProcesses': observed,
    'scope': 'Research only; no production acceptance, worker descendant audit, full negative-input regression, or five-round performance matrix.',
}
(root / 'workspace-audit.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: v for k, v in result.items() if k != 'observedProcesses'}, indent=2))
