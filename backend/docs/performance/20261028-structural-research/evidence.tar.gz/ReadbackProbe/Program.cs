using System.Diagnostics;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text.Json;
using SkiaSharp;

// Isolated diagnostic: calls the unchanged first-batch device assembly.
string backend = args[0], output = args[1];
bool colorStudy = args.Length > 2 && args[2] == "color";
bool topLeft = args.Length > 3 && args[3] == "top-left";
Environment.SetEnvironmentVariable("MAKO_RENDER_BACKEND", backend);
var assembly = Assembly.Load("MakoKaraGenerator.Rendering.Skia");
var factory = assembly.GetType("MakoKaraGenerator.Rendering.Skia.SkiaRenderDeviceFactory", true)!;
using var device = (IDisposable)factory.GetMethod("Create")!.Invoke(null, [null])!;
var type = device.GetType();
var create = type.GetMethod("CreateSurface")!.CreateDelegate<Func<SKImageInfo, SKSurface>>(device);
var submit = type.GetMethod("FlushAndSubmit")!.CreateDelegate<Action<SKSurface>>(device);
var context = type.GetField("_context", BindingFlags.NonPublic | BindingFlags.Instance)?.GetValue(device) as GRContext;
if (topLeft && context is not null)
    create = info => SKSurface.Create((GRRecordingContext)context, true, info, 0, GRSurfaceOrigin.TopLeft)
        ?? throw new InvalidOperationException("Top-left surface creation failed");
var infoString = type.GetProperty("Info")!.GetValue(device)!.ToString();
const int width = 1920, height = 1080, rowBytes = width * 4, length = rowBytes * height;
byte[] bytes = new byte[length];
var pin = GCHandle.Alloc(bytes, GCHandleType.Pinned);
var records = new List<object>();
var directImageChecks = new List<object>();
int mismatches = 0;
try
{
    foreach (bool srgb in new[] { false, true })
    {
        using var colorSpace = srgb ? SKColorSpace.CreateSrgb() : null;
        var info = new SKImageInfo(width, height, SKColorType.Bgra8888, SKAlphaType.Premul, colorSpace);
        var readInfo = new SKImageInfo(width, height, SKColorType.Bgra8888, SKAlphaType.Premul);
        for (int iteration = -2; iteration < 6; iteration++)
        {
            string? expected = null;
            string[] methods = colorStudy
                ? ["surface-explicit-sync", "surface-matched-color", "image-direct-null", "image-direct-matched"]
                : ["surface-explicit-sync", "image-production-staged", "image-scratch-surface", "surface-read-sync"];
            int rotation = (iteration + 2) % methods.Length;
            foreach (string method in methods.Skip(rotation).Concat(methods.Take(rotation)))
            {
                var times = new Dictionary<string, double>();
                SKSurface surface = null!;
                times["create"] = Measure(() => surface = create(info));
                using (surface)
                {
                    times["draw"] = Measure(() => Draw(surface.Canvas, iteration));
                    bool ok = false;
                    string? imageColor = null, imageAlpha = null;
                    bool? texture = null;
                    if (method == "surface-read-sync")
                    {
                        times["read"] = Measure(() => ok = surface.ReadPixels(readInfo, pin.AddrOfPinnedObject(), rowBytes, 0, 0));
                    }
                    else
                    {
                        times["producerSubmit"] = Measure(() => submit(surface));
                        if (method == "surface-matched-color")
                            times["read"] = Measure(() => ok = surface.ReadPixels(info, pin.AddrOfPinnedObject(), rowBytes, 0, 0));
                        else if (method == "surface-explicit-sync")
                            times["read"] = Measure(() => ok = surface.ReadPixels(readInfo, pin.AddrOfPinnedObject(), rowBytes, 0, 0));
                        else
                        {
                            SKImage image = null!;
                            times["snapshot"] = Measure(() => image = surface.Snapshot());
                            using (image)
                            {
                                imageColor = image.ColorType.ToString(); imageAlpha = image.AlphaType.ToString(); texture = image.IsTextureBacked;
                                if (method.StartsWith("image-direct", StringComparison.Ordinal))
                                {
                                    // Fresh snapshot, before any rasterization; dispose producer too.
                                    surface.Dispose();
                                    times["read"] = Measure(() => ok = image.ReadPixels(method == "image-direct-matched" ? info : readInfo,
                                        pin.AddrOfPinnedObject(), rowBytes, 0, 0));
                                }
                                else if (method == "image-production-staged")
                                {
                                    times["consumerSubmit"] = Measure(() => { context?.Flush(); context?.Submit(true); });
                                    SKImage raster = null!;
                                    times["toRaster"] = Measure(() => raster = image.ToRasterImage(true));
                                    if (raster is null) throw new InvalidOperationException("Raster image unavailable");
                                    try { times["rasterCopy"] = Measure(() => ok = raster.ReadPixels(readInfo, pin.AddrOfPinnedObject(), rowBytes, 0, 0)); }
                                    finally { if (!ReferenceEquals(raster, image)) raster.Dispose(); }
                                }
                                else
                                {
                                    SKSurface scratch = null!;
                                    times["scratchCreate"] = Measure(() => scratch = create(info));
                                    using (scratch)
                                    {
                                        times["scratchDraw"] = Measure(() =>
                                        {
                                            scratch.Canvas.ClipRect(new(0, 0, width, height)); scratch.Canvas.Clear(SKColors.Transparent);
                                            using var paint = new SKPaint { BlendMode = SKBlendMode.Src, IsAntialias = false };
                                            scratch.Canvas.DrawImage(image, 0, 0, paint);
                                        });
                                        times["read"] = Measure(() => ok = scratch.ReadPixels(readInfo, pin.AddrOfPinnedObject(), rowBytes, 0, 0));
                                    }
                                }
                                if (iteration == -2 && method == "image-production-staged")
                                {
                                    byte[] direct = new byte[length];
                                    var directPin = GCHandle.Alloc(direct, GCHandleType.Pinned);
                                    try
                                    {
                                        bool directOk = image.ReadPixels(readInfo, directPin.AddrOfPinnedObject(), rowBytes, 0, 0);
                                        directImageChecks.Add(new { srgb, ok = directOk, exactIfSuccessful = directOk && direct.AsSpan().SequenceEqual(bytes) });
                                    }
                                    finally { directPin.Free(); }
                                }
                            }
                        }
                    }
                    if (!ok) throw new InvalidOperationException(method + " failed");
                    string hash = Convert.ToHexStringLower(SHA256.HashData(bytes));
                    expected ??= hash;
                    if (hash != expected) mismatches++;
                    records.Add(new { srgb, iteration, phase = iteration < 0 ? "warmup" : "measure", method, times, hash, imageColor, imageAlpha, texture });
                }
            }
        }
    }
}
finally { pin.Free(); }
var evidence = new { schema = "isolated-readback-diagnostic-v1", backend, device = infoString, width, height,
    processId = Environment.ProcessId, startedUtc = Process.GetCurrentProcess().StartTime.ToUniversalTime(),
    assemblySha256 = Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(assembly.Location))),
    scope = "Synthetic surface microprobe; no Runtime fixtures; stage timings include synchronization; no production changes.",
    colorStudy, topLeft, surfaces = colorStudy ? 64 : 80, records, directImageChecks, mismatches };
File.WriteAllText(output, JsonSerializer.Serialize(evidence, new JsonSerializerOptions { WriteIndented = true }) + "\n");
if (mismatches != 0) throw new InvalidOperationException($"Pixel mismatches: {mismatches}");

static double Measure(Action action) { var start = Stopwatch.GetTimestamp(); action(); return Stopwatch.GetElapsedTime(start).TotalMilliseconds; }
static void Draw(SKCanvas canvas, int seed)
{
    canvas.ClipRect(new(0, 0, width, height)); canvas.Clear(SKColors.Transparent);
    using var gradient = SKShader.CreateLinearGradient(new(0, 0), new(width, height), [new SKColor(200, 40, 80, 137), new SKColor(20, 180, 220, 223)], SKShaderTileMode.Clamp);
    using var paint = new SKPaint { Shader = gradient, IsAntialias = false, BlendMode = SKBlendMode.Src };
    canvas.DrawRect(new(10 + seed, 23, 1860, 1030), paint);
    paint.Shader = null; paint.Color = new(70, 220, 40, 99); paint.BlendMode = SKBlendMode.SrcOver;
    canvas.DrawRect(new(121, 155 + seed, 930, 750), paint);
}
