| 场景 | 后端 | 执行体 | 帧数 | 单帧中位数 ms | P95 ms | 新会话创建中位数 ms | 首帧中位数 ms |
|---|---|---|---:|---:|---:|---:|---:|
| combined | cpu | new-instrumented | 8 | 4784.406 | 4862.891 | 1054.799 | 5149.901 |
| combined | cpu | old-instrumented | 8 | 4943.919 | 5021.819 | 1041.672 | 5445.807 |
| combined | vulkan | new-instrumented | 8 | 1106.909 | 1171.551 | 1105.901 | 1537.257 |
| combined | vulkan | old-instrumented | 8 | 2292.713 | 2315.105 | 1122.542 | 2798.097 |
| material | cpu | new-instrumented | 8 | 4409.769 | 4431.220 | 199.307 | 4673.112 |
| material | cpu | old-instrumented | 8 | 4448.077 | 4526.175 | 195.704 | 4642.233 |
| material | vulkan | new-instrumented | 8 | 1003.939 | 1024.265 | 236.804 | 1311.175 |
| material | vulkan | old-instrumented | 8 | 1885.491 | 1901.996 | 454.709 | 2637.301 |
