| 场景 | 后端 | 执行体 | 帧数 | 单帧中位数 ms | P95 ms | 新会话创建中位数 ms | 首帧中位数 ms |
|---|---|---|---:|---:|---:|---:|---:|
| combined | cpu | baseline | 2 | 5505.878 | 5573.077 | 1295.846 | 5578.834 |
| combined | vulkan | baseline | 2 | 2762.726 | 2805.192 | 1370.417 | 3383.537 |
| csharp | cpu | baseline | 2 | 6.147 | 7.157 | 1021.230 | 206.200 |
| csharp | vulkan | baseline | 2 | 6.752 | 7.357 | 1074.984 | 197.223 |
| graph | cpu | baseline | 2 | 791.325 | 825.964 | 460.961 | 1358.584 |
| graph | vulkan | baseline | 2 | 152.071 | 154.141 | 517.070 | 559.586 |
| material | cpu | baseline | 2 | 4575.840 | 4599.925 | 215.777 | 4963.629 |
| material | vulkan | baseline | 2 | 2127.122 | 2136.999 | 387.008 | 2478.527 |
| particle | cpu | baseline | 2 | 6.102 | 6.296 | 1630.697 | 295.135 |
| particle | vulkan | baseline | 2 | 15.429 | 16.328 | 1770.089 | 596.153 |
