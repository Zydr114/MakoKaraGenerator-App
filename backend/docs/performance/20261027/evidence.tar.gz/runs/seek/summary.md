| 场景 | 后端 | 执行体 | 帧数 | 单帧中位数 ms | P95 ms | 新会话创建中位数 ms | 首帧中位数 ms |
|---|---|---|---:|---:|---:|---:|---:|
| csharp | cpu | baseline | 24 | 13.572 | 203.441 | 1002.793 | 204.412 |
| csharp | cpu | instrumented | 24 | 9.901 | 204.247 | 978.838 | 204.580 |
| csharp | vulkan | baseline | 24 | 11.683 | 196.799 | 1065.008 | 197.620 |
| csharp | vulkan | instrumented | 24 | 11.886 | 197.536 | 1285.674 | 197.624 |
| particle | cpu | baseline | 24 | 17.919 | 285.363 | 889.033 | 286.880 |
| particle | cpu | instrumented | 24 | 19.955 | 282.669 | 1043.909 | 283.170 |
| particle | vulkan | baseline | 24 | 20.439 | 273.817 | 912.530 | 275.033 |
| particle | vulkan | instrumented | 24 | 24.664 | 268.672 | 917.372 | 269.168 |
