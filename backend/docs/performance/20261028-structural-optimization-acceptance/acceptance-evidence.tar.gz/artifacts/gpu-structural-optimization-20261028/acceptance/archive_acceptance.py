from pathlib import Path
import gzip, hashlib, io, json, tarfile

ROOT = Path.cwd()
BASE = ROOT / 'artifacts/gpu-structural-optimization-20261028'
OUT = ROOT / 'docs/performance/20261028-structural-optimization-acceptance'
OUT.mkdir(exist_ok=False)
entries = {}
def add(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink(), path
    entries[path.relative_to(ROOT).as_posix()] = path.read_bytes()

for path in (BASE/'acceptance/regression-final1').iterdir():
    if path.is_file() and path.suffix in ('.json', '.trx', '.log'): add(path)
for name in ('regression.py', 'performance.py', 'archive_acceptance.py', 'acceptance-summary.json',
             'deployment-audit.json', 'oracle-worker-dll-differences.json', 'oracle-worker-dll-audit.json',
             'metadata-build.log', 'oracle-build.log', 'oracle-rebuild-103ba2c.log',
             'contract-validation.json', 'contract-http-summary.json', 'contract-http-detailed.json',
             'telemetry-http-audit.json', 'before-performance-processes.txt'):
    add(BASE/'acceptance'/name)
for name in ('deployment.json', 'server-publish.log', 'worker-publish.log'):
    add(BASE/'acceptance/dist-103ba2c'/name)
for name in ('http-summary-final1', 'http-summary-final2', 'http-detailed-final1'):
    directory = BASE/'acceptance'/name
    for item in ('summary.json', 'gpu-render-final-shutdown.json', 'evidence-manifest.json',
                 'gpu-environment.json', 'gpu-worker-evidence.json'):
        add(directory/item)
    for path in directory.glob('profile/runs/*/server.log'): add(path)
    if (directory/'failure.txt').exists(): add(directory/'failure.txt')
for name in ('mutation-red-2.trx', 'mutation-green-2.trx', 'telemetry-mutation-red-2.trx',
             'telemetry-restored-green.trx', 'skia-telemetry-final-2.trx'):
    add(BASE/'owned-readback'/name)
for name in ('author-cache-assertion-mutation-report.json', 'author-cache-assertion-mutation-red.trx',
             'author-cache-assertion-mutation-red.log', 'author-cache-assertion-restore-green.trx',
             'author-cache-assertion-restore-green.log'):
    add(ROOT/'artifacts/author-cache-20261028'/name)
for name in ('assessment.json', 'commands.json'): add(BASE/'tool-checks'/name)

digest = lambda b: hashlib.sha256(b).hexdigest()
archive = OUT/'acceptance-evidence.tar.gz'
with archive.open('xb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as tar:
            for name, data in sorted(entries.items()):
                info=tarfile.TarInfo(name); info.size=len(data); info.mode=0o644
                info.mtime=info.uid=info.gid=0; info.uname=info.gname=''
                tar.addfile(info,io.BytesIO(data))
index={'schema':'structural-optimization-acceptance-evidence-v1',
       'productionCommit':'5802ac146fcaa89ad882229b0b3e1615c15dc5b0',
       'deploymentCommit':'103ba2cc1adafe91f4256803c20a93aabdb82875',
       'files':{name:{'sha256':digest(data),'bytes':len(data)} for name,data in sorted(entries.items())},
       'archive':{'path':archive.name,'sha256':digest(archive.read_bytes()),'bytes':archive.stat().st_size},
       'scope':'Local regression and finite HTTP/log evidence. Failed first HTTP run retained separately. No formal performance result yet. Raw HTTP payloads and media are retained locally and indexed, not included in this compact archive.'}
(OUT/'evidence-index.json').write_text(json.dumps(index,indent=2)+'\n')
for name in ('acceptance-summary.json','telemetry-http-audit.json'):
    (OUT/name).write_bytes((BASE/'acceptance'/name).read_bytes())
with tarfile.open(archive) as tar:
    assert len(tar.getmembers())==len(entries)
    for item in tar:
        assert digest(tar.extractfile(item).read())==index['files'][item.name]['sha256']
print(json.dumps({'files':len(entries),**index['archive']},indent=2))
