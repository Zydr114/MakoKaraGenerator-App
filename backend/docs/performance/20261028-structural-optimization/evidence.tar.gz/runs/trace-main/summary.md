| 场景 | 后端 | 执行体 | 监控模式 | 帧数 | 单帧中位数 ms | P95 ms | 新会话创建中位数 ms | 首帧中位数 ms |
|---|---|---|---|---:|---:|---:|---:|---:|
| csharp | cpu | new-instrumented | off | 24 | 3.186 | 4.180 | 1050.377 | 201.791 |
| csharp | cpu | old-instrumented | off | 24 | 3.454 | 6.410 | 979.810 | 194.668 |
| csharp | vulkan | new-instrumented | off | 24 | 5.070 | 7.720 | 1085.385 | 204.693 |
| csharp | vulkan | old-instrumented | off | 24 | 5.956 | 7.651 | 966.425 | 186.557 |
| graph | cpu | new-instrumented | off | 24 | 416.456 | 513.994 | 240.755 | 727.375 |
| graph | cpu | old-instrumented | off | 24 | 431.073 | 455.133 | 213.513 | 611.601 |
| graph | vulkan | new-instrumented | off | 24 | 33.007 | 35.005 | 408.487 | 273.818 |
| graph | vulkan | old-instrumented | off | 24 | 95.141 | 130.712 | 484.255 | 446.300 |
| lyrics | cpu | new-instrumented | off | 24 | 0.918 | 1.589 | 9.692 | 105.204 |
| lyrics | cpu | old-instrumented | off | 24 | 1.039 | 1.242 | 8.802 | 102.051 |
| lyrics | vulkan | new-instrumented | off | 24 | 2.602 | 3.819 | 69.445 | 121.508 |
| lyrics | vulkan | old-instrumented | off | 24 | 2.487 | 3.243 | 94.580 | 143.493 |
| particle | cpu | new-instrumented | off | 24 | 5.186 | 8.466 | 1554.095 | 313.889 |
| particle | cpu | old-instrumented | off | 24 | 5.632 | 9.155 | 838.183 | 265.754 |
| particle | vulkan | new-instrumented | off | 24 | 7.724 | 10.167 | 1253.902 | 257.599 |
| particle | vulkan | old-instrumented | off | 24 | 6.820 | 10.466 | 956.873 | 261.271 |
