from pathlib import Path
from collections import defaultdict
import hashlib
import json
import math
import statistics

root = Path(__file__).resolve().parent

def read(path):
    return json.loads(path.read_text())

def summary(xs):
    ys = sorted(xs)
    pos = (len(ys) - 1) * .95
    lo = math.floor(pos)
    return {'n': len(ys), 'medianMs': statistics.median(ys),
            'p95Ms': ys[lo] + (ys[min(lo + 1, len(ys) - 1)] - ys[lo]) * (pos - lo), 'maxMs': max(ys)}

result = {'scope': 'Research evidence only; original first-batch results remain unchanged.', 'micro': {}, 'runtime': {}}
for label in ['runs', 'color-runs', 'origin-runs']:
    groups = defaultdict(list)
    files = list((root / label).glob('r*.json'))
    for p in files:
        data = read(p)
        assert data['mismatches'] == 0
        for row in data['records']:
            if row['phase'] == 'measure':
                groups[(data['backend'], row['srgb'], row['method'])].append(row)
    result['micro'][label] = {'processes': len(files), 'groups': [
        {'backend': k[0], 'srgb': k[1], 'method': k[2], 'totalStageSum': summary([sum(r['times'].values()) for r in rows]),
         'stages': {stage: summary([r['times'][stage] for r in rows]) for stage in rows[0]['times']}}
        for k, rows in sorted(groups.items())]}

origin = {'matches': 0, 'mismatches': 0}
for p in (root / 'origin-runs').glob('r*.json'):
    for a, b in zip(read(p)['records'], read(root / 'color-runs' / p.name)['records'], strict=True):
        assert (a['method'], a['srgb'], a['iteration']) == (b['method'], b['srgb'], b['iteration'])
        origin['matches' if a['hash'] == b['hash'] else 'mismatches'] += 1
result['micro']['originComparison'] = origin

for label in ['runtime-runs', 'followup-runs']:
    manifest = read(root / label / 'manifest.json')
    assert all(r['exitCode'] == 0 for r in manifest)
    pairs = []
    for p in sorted((root / label).glob('*.json')):
        if 'matched-read' not in p.name and 'top-left' not in p.name:
            continue
        bp = p.with_name(p.name.replace('matched-read', 'baseline').replace('top-left', 'baseline'))
        a, b = read(bp), read(p)
        for key in ['fixtureSha256', 'backend', 'width', 'height', 'mode', 'transparent', 'quality']:
            assert a[key] == b[key]
        comparisons = []
        for x, y in zip(a['frames'], b['frames'], strict=True):
            assert x['timeUs'] == y['timeUs'] and x['pixelBytes'] == y['pixelBytes']
            comparisons.append({'index': x['index'], 'timeUs': x['timeUs'], 'pixelEqual': x['bgraSha256'] == y['bgraSha256'],
                                'diagnosticEqual': x['diagnostics'] == y['diagnostics'] and x['diagnosticSha256'] == y['diagnosticSha256']})
        if 'matched-read' in p.name:
            assert all(c['pixelEqual'] and c['diagnosticEqual'] for c in comparisons)
        pairs.append({'candidate': p.name, 'baseline': bp.name, 'frames': comparisons})
    result['runtime'][label] = {'processes': len(manifest), 'allExitCodesZero': True, 'pairs': pairs}

paired = []
for scenario in ['graph', 'material', 'combined']:
    row = {'scenario': scenario}
    for variant in ['baseline', 'matched-read']:
        processes = [read(p) for p in sorted((root / 'followup-runs').glob(f'paired-r*-{scenario}-{variant}.json'))]
        assert len(processes) == 3
        frames = [f for d in processes for f in d['frames'] if f['phase'] == 'steady']
        row[variant] = {'wall': summary([f['wallMs'] for f in frames]),
                        'roundMediansMs': [statistics.median(f['wallMs'] for f in d['frames'] if f['phase'] == 'steady') for d in processes],
                        'createMedianMs': statistics.median(d['create']['wallMs'] for d in processes),
                        'coldMedianMs': statistics.median(d['frames'][0]['wallMs'] for d in processes)}
    row['medianReductionPercent'] = (1 - row['matched-read']['wall']['medianMs'] / row['baseline']['wall']['medianMs']) * 100
    paired.append(row)
result['pairedRuntime'] = paired

historical = root / 'historical-traces'
trace = []
for scenario in ['lyrics', 'csharp', 'graph', 'material', 'particle', 'combined']:
    label = 'trace-heavy' if scenario in ['material', 'combined'] else 'trace-main'
    for backend in ['cpu', 'vulkan']:
        path = historical / label / f'r01-{scenario}-{backend}-new-instrumented.json'
        data = read(path)
        frames = [f for f in data['frames'] if f['phase'] == 'steady']
        names = sorted({s['name'] for f in frames for s in f['trace']['stages']})
        stages = []
        for name in names:
            ss = [next((s for s in f['trace']['stages'] if s['name'] == name), {'calls': 0, 'inclusiveMs': 0, 'exclusiveMs': 0}) for f in frames]
            stages.append({'name': name, 'calls': sorted({s['calls'] for s in ss}),
                           'inclusiveMedianMs': statistics.median(s['inclusiveMs'] for s in ss),
                           'exclusiveMedianMs': statistics.median(s['exclusiveMs'] for s in ss)})
        trace.append({'scenario': scenario, 'backend': backend, 'source': str(path.relative_to(root)),
                      'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'frames': len(frames),
                      'wall': summary([f['wallMs'] for f in frames]), 'stages': stages})
result['historicalTraceReanalysis'] = trace
(root / 'assessment.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(paired, indent=2))
print('origin micro comparison', origin)
for label, data in result['runtime'].items():
    print(label, 'processes', data['processes'], 'pair frames', sum(len(p['frames']) for p in data['pairs']),
          'unequal pixel pairs', sum(not f['pixelEqual'] for p in data['pairs'] for f in p['frames']))
