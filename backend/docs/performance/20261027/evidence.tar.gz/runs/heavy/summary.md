| 场景 | 后端 | 执行体 | 帧数 | 单帧中位数 ms | P95 ms | 新会话创建中位数 ms | 首帧中位数 ms |
|---|---|---|---:|---:|---:|---:|---:|
| combined | cpu | baseline | 40 | 5069.729 | 5347.129 | 1157.905 | 5717.310 |
| combined | cpu | instrumented | 40 | 5153.749 | 5438.045 | 1141.116 | 5707.831 |
| combined | vulkan | baseline | 40 | 2551.087 | 2625.710 | 1159.122 | 3040.093 |
| combined | vulkan | instrumented | 40 | 2516.904 | 2907.808 | 1216.007 | 3017.799 |
| material | cpu | baseline | 40 | 4713.954 | 5092.907 | 255.945 | 4976.986 |
| material | cpu | instrumented | 40 | 4543.446 | 4777.387 | 201.078 | 4948.426 |
| material | vulkan | baseline | 40 | 2038.934 | 2065.962 | 237.234 | 2371.113 |
| material | vulkan | instrumented | 40 | 1993.622 | 2234.711 | 410.010 | 2657.048 |
