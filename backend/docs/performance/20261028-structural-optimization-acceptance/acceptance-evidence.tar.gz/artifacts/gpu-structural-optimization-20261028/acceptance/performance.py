from pathlib import Path
import datetime, json, os, subprocess, sys, time

ROOT=Path.cwd()
OUT=ROOT/'artifacts/gpu-structural-optimization-20261028/ab-final1'
TOOL=ROOT/'tools/backend-render-performance'
records=[]
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def run(name,args):
    record={'name':name,'command':args,'startedUtc':stamp()};records.append(record)
    def save():(OUT/'orchestration.json').write_text(json.dumps(records,indent=2)+'\n')
    save();print('START '+name,flush=True)
    begin=time.monotonic()
    with (OUT/(name+'.orchestration.log')).open('w') as log:
        code=subprocess.call(args,stdout=log,stderr=subprocess.STDOUT)
    record.update(exitCode=code,elapsedSeconds=time.monotonic()-begin,completedUtc=stamp());save()
    print('DONE '+name+' '+str(code),flush=True)
    if code:raise RuntimeError(name+' failed; evidence preserved')
def loadcheck(name):
    processes=subprocess.check_output(['ps','-eo','pid,pcpu,pmem,comm','--sort=-pcpu'],text=True)
    (OUT/(name+'.process-load.txt')).write_text(processes)
    if any(line.split()[-1] in {'cs2','vkcube','glmark2','glxgears'} for line in processes.splitlines()[1:]):
        raise RuntimeError('unrelated GPU workload; do not use this batch as formal evidence')
specs=[
 ('main',['--scenarios','lyrics,csharp,graph,particle','--rounds','5','--warmup','8','--frames','24']),
 ('heavy',['--scenarios','material,combined','--rounds','5','--warmup','4','--frames','8']),
 ('seek',['--rounds','1','--mode','seek','--warmup','0','--frames','8']),
 ('transparent',['--rounds','1','--transparent','--warmup','1','--frames','2']),
 ('trace-main',['--scenarios','lyrics,csharp,graph,particle','--rounds','1','--warmup','8','--frames','24']),
 ('trace-heavy',['--scenarios','material,combined','--rounds','1','--warmup','4','--frames','8']),
 ('monitoring',['--scenarios','lyrics,csharp,combined','--rounds','3','--warmup','4','--frames','8']),
]
for label,args in specs:
    loadcheck(label)
    monitoring=label=='monitoring'
    variants=['--variant','new'] if monitoring else ['--variants','old-instrumented,new-instrumented' if label.startswith('trace-') else 'old,new']
    run(label,[sys.executable,str(TOOL/'bench.py'),'run-monitoring' if monitoring else 'run','--output',str(OUT),'--label',label]+variants+args)
    run('analyze-'+label,[sys.executable,str(TOOL/'analyze.py'),'--output',str(OUT),'--label',label])
for label in ('main','heavy'):
    run('compare-trace-'+label,[sys.executable,str(TOOL/'analyze.py'),'--output',str(OUT),'--original-label',label,'--traced-label','trace-'+label])
