| 场景 | 后端 | 执行体 | 帧数 | 单帧中位数 ms | P95 ms | 新会话创建中位数 ms | 首帧中位数 ms |
|---|---|---|---:|---:|---:|---:|---:|
| csharp | cpu | baseline | 2 | 2.690 | 3.258 | 15.648 | 206.214 |
| csharp | vulkan | baseline | 2 | 5.507 | 6.361 | 63.413 | 185.318 |
| graph | cpu | baseline | 2 | 1.771 | 2.222 | 11.069 | 143.620 |
| graph | vulkan | baseline | 2 | 3.627 | 4.476 | 50.830 | 98.531 |
| material | cpu | baseline | 2 | 2.004 | 2.462 | 11.439 | 152.565 |
| material | vulkan | baseline | 2 | 3.660 | 4.358 | 56.712 | 101.486 |
| particle | cpu | baseline | 2 | 1.472 | 1.742 | 8.037 | 102.624 |
| particle | vulkan | baseline | 2 | 5.295 | 6.250 | 51.349 | 179.757 |
