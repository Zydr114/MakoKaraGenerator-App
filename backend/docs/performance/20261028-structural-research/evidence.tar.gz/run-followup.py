from pathlib import Path
import hashlib
import json
import subprocess
import time

root = Path(__file__).resolve().parent
repo = root.parents[1]
sources = {'baseline': repo / 'artifacts/performance-optimization-20261027-ab-resumed/sources/new',
           'matched-read': root / 'source-matched-read'}
out = root / 'followup-runs'
out.mkdir(exist_ok=True)
manifest = []
jobs = []
for r in range(1, 4):
    for s in ['graph', 'material', 'combined']:
        for v in (['baseline', 'matched-read'] if r % 2 else ['matched-read', 'baseline']):
            jobs.append((f'paired-r{r}-{s}-{v}', s, v, ['--warmup', '4', '--frames', '8']))
for mode in ['transparent', 'seek']:
    for s in ['graph', 'material', 'combined']:
        for v in ['baseline', 'matched-read']:
            settings = ['--warmup', '1', '--frames', '2', '--transparent', 'true'] if mode == 'transparent' else ['--mode', 'seek', '--warmup', '0', '--frames', '8']
            jobs.append((f'{mode}-{s}-{v}', s, v, settings))
for stem, scenario, variant, settings in jobs:
    source = sources[variant]
    dll = source / 'tools/backend-render-performance/Runner/bin/Release/net10.0/Runner.dll'
    command = ['dotnet', str(dll), '--source-root', str(source), '--scenario', scenario, '--backend', 'vulkan',
               '--output', str(out / (stem + '.json')), '--cache-root', str(root / 'cache' / stem), *settings]
    start = time.time()
    p = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    stdout, _ = p.communicate(timeout=75)
    (out / (stem + '.log')).write_text(stdout)
    manifest.append({'scenario': scenario, 'variant': variant, 'label': stem, 'command': command,
                     'pid': p.pid, 'exitCode': p.returncode, 'wallSeconds': time.time() - start,
                     'runnerSha256': hashlib.sha256(dll.read_bytes()).hexdigest(),
                     'renderingSha256': hashlib.sha256((dll.parent / 'MakoKaraGenerator.Rendering.Skia.dll').read_bytes()).hexdigest()})
    (out / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(stem, p.returncode, round(time.time() - start, 3), flush=True)
    if p.returncode:
        print(stdout)
        raise SystemExit(p.returncode)
