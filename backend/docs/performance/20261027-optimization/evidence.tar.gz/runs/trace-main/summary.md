| 场景 | 后端 | 执行体 | 帧数 | 单帧中位数 ms | P95 ms | 新会话创建中位数 ms | 首帧中位数 ms |
|---|---|---|---:|---:|---:|---:|---:|
| csharp | cpu | new-instrumented | 24 | 3.136 | 3.950 | 939.875 | 189.680 |
| csharp | cpu | old-instrumented | 24 | 3.161 | 4.155 | 1682.440 | 268.246 |
| csharp | vulkan | new-instrumented | 24 | 4.786 | 6.562 | 961.378 | 181.030 |
| csharp | vulkan | old-instrumented | 24 | 5.550 | 8.116 | 970.408 | 183.293 |
| graph | cpu | new-instrumented | 24 | 417.906 | 422.120 | 242.997 | 644.242 |
| graph | cpu | old-instrumented | 24 | 429.205 | 435.165 | 447.653 | 1366.891 |
| graph | vulkan | new-instrumented | 24 | 88.855 | 94.406 | 251.194 | 323.787 |
| graph | vulkan | old-instrumented | 24 | 152.164 | 158.825 | 486.240 | 540.300 |
| lyrics | cpu | new-instrumented | 24 | 1.700 | 2.493 | 10.246 | 95.559 |
| lyrics | cpu | old-instrumented | 24 | 0.882 | 1.152 | 17.281 | 95.513 |
| lyrics | vulkan | new-instrumented | 24 | 3.950 | 4.389 | 92.320 | 175.828 |
| lyrics | vulkan | old-instrumented | 24 | 2.977 | 3.689 | 67.366 | 121.588 |
| particle | cpu | new-instrumented | 24 | 5.904 | 8.741 | 843.640 | 271.262 |
| particle | cpu | old-instrumented | 24 | 5.263 | 8.749 | 854.510 | 271.028 |
| particle | vulkan | new-instrumented | 24 | 6.983 | 8.997 | 900.034 | 262.370 |
| particle | vulkan | old-instrumented | 24 | 7.444 | 9.815 | 893.727 | 260.021 |
