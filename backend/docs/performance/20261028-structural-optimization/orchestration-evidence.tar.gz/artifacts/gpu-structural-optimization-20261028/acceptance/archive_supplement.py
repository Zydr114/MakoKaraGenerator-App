from pathlib import Path
import gzip, hashlib, io, json, tarfile

ROOT=Path.cwd()
OUT=ROOT/'artifacts/gpu-structural-optimization-20261028/ab-final1'
ACCEPT=ROOT/'artifacts/gpu-structural-optimization-20261028/acceptance'
DEST=ROOT/'docs/performance/20261028-structural-optimization'
assert (DEST/'evidence-index.json').exists()
paths=set()
for pattern in ('*.process-load.txt','*.orchestration.log','orchestration.json','window-process-load.jsonl',
                'resumed-preflight.json','compact-performance-comparison.json','comparison-table.md'):
    paths.update(OUT.glob(pattern))
for name in ('performance.py','summarize_performance.py','archive_supplement.py','main-review.json','final-performance-review.json'):
    p=ACCEPT/name
    if p.exists():paths.add(p)
entries={str(p.relative_to(ROOT)):p.read_bytes() for p in sorted(paths)}
digest=lambda x:hashlib.sha256(x).hexdigest()
archive=DEST/'orchestration-evidence.tar.gz'
with archive.open('xb') as raw:
    with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as compressed:
        with tarfile.open(fileobj=compressed,mode='w',format=tarfile.PAX_FORMAT) as tar:
            for name,data in entries.items():
                info=tarfile.TarInfo(name); info.size=len(data);info.mode=0o644
                info.mtime=info.uid=info.gid=0; info.uname=info.gname=''
                tar.addfile(info,io.BytesIO(data))
index={'schema':'performance-orchestration-evidence-v1',
    'files':{n:{'sha256':digest(b),'bytes':len(b)} for n,b in entries.items()},
    'archive':{'path':archive.name,'sha256':digest(archive.read_bytes()),'bytes':archive.stat().st_size},
    'scope':'Supplement to Runtime archive: orchestration, source preflight and process-load observations. Snapshots cannot prove exclusive hardware access between observations.'}
(DEST/'orchestration-index.json').write_text(json.dumps(index,indent=2)+'\n')
(DEST/'compact-performance-comparison.json').write_bytes((OUT/'compact-performance-comparison.json').read_bytes())
with tarfile.open(archive) as tar:
    for item in tar:assert digest(tar.extractfile(item).read())==index['files'][item.name]['sha256']
print(json.dumps({'files':len(entries),**index['archive']},indent=2))
