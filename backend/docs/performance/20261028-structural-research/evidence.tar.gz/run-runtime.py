from pathlib import Path
import hashlib
import json
import subprocess
import time

root = Path(__file__).resolve().parent
repo = root.parents[1]
baseline = repo / 'artifacts/performance-optimization-20261027-ab-resumed/sources/new'
sources = {'baseline': baseline, 'top-left': root / 'source-top-left', 'matched-read': root / 'source-matched-read'}
out = root / 'runtime-runs'
out.mkdir(exist_ok=True)
manifest = []
for scenario in ['lyrics', 'graph', 'material', 'combined']:
    for variant in ['baseline', 'top-left', 'matched-read']:
        source = sources[variant]
        dll = source / 'tools/backend-render-performance/Runner/bin/Release/net10.0/Runner.dll'
        stem = f'r1-{scenario}-{variant}'
        command = ['dotnet', str(dll), '--source-root', str(source), '--scenario', scenario, '--backend', 'vulkan',
                   '--output', str(out / (stem + '.json')), '--cache-root', str(root / 'cache' / stem), '--warmup', '2', '--frames', '3']
        start = time.time()
        p = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        stdout, _ = p.communicate(timeout=60)
        (out / (stem + '.log')).write_text(stdout)
        manifest.append({'scenario': scenario, 'variant': variant, 'round': 1, 'command': command,
                         'pid': p.pid, 'exitCode': p.returncode, 'wallSeconds': time.time() - start,
                         'runnerSha256': hashlib.sha256(dll.read_bytes()).hexdigest(),
                         'renderingSha256': hashlib.sha256((dll.parent / 'MakoKaraGenerator.Rendering.Skia.dll').read_bytes()).hexdigest()})
        (out / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
        print(stem, p.returncode, round(time.time() - start, 3), flush=True)
        if p.returncode:
            print(stdout)
            raise SystemExit(p.returncode)
