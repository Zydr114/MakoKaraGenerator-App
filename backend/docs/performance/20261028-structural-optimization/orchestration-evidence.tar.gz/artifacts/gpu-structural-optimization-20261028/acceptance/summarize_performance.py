from pathlib import Path
import json, hashlib, statistics

ROOT=Path.cwd()
OUT=ROOT/'artifacts/gpu-structural-optimization-20261028/ab-final1'
DEST=OUT/'compact-performance-comparison.json'
labels=['main','heavy','seek','transparent','trace-main','trace-heavy','monitoring']
summaries={label:json.loads((OUT/'runs'/label/'summary.json').read_text()) for label in labels}
assert all(s['assessment']['valid'] for s in summaries.values())
comparison=[]
for label in ['main','heavy']:
    groups={(g['scenario'],g['backend'],g['variant']):g for g in summaries[label]['groups']}
    for scenario,backend,variant in sorted(groups):
        if variant!='old': continue
        old,new=groups[scenario,backend,'old'],groups[scenario,backend,'new']
        comparison.append({'label':label,'scenario':scenario,'backend':backend,
            'old':{k:old[k] for k in ('frameWallMs','roundMedians','createWallMs','firstFrameWallMs','allocatedBytes','gcCollections')},
            'new':{k:new[k] for k in ('frameWallMs','roundMedians','createWallMs','firstFrameWallMs','allocatedBytes','gcCollections')},
            'medianReductionPercent':100*(1-new['frameWallMs']['median']/old['frameWallMs']['median']),
            'roundMedianReductionsPercent':[100*(1-b/a) for a,b in zip(old['roundMedians'],new['roundMedians'])]})
telemetry={}
for f in sorted((OUT/'runs/monitoring').glob('*.monitoring.jsonl')):
    events=[json.loads(x.split('MAKO_PERFORMANCE_V1 ',1)[1]) for x in f.read_text().splitlines()]
    sums=[e for e in events if e['Kind']=='summary']
    telemetry[f.name]={'events':len(events),'summaries':len(sums),'details':sum(e['Kind']=='frame' for e in events),
        'completedFrames':sum(e['Frames'] for e in sums),'reportedDropped':sum(e['Dropped'] for e in sums),
        'errors':sum(e['Errors'] for e in sums),'cancelled':sum(e['Cancelled'] for e in sums),
        'nonzeroFields':sorted({k for e in events for k in ('PrepareMs','ScriptMs','ScriptCalls','GraphMs','MaterialMs','ParticleMs','RasterMs','ValidationMs','ReadbackMs','ImageReads','SurfaceReads') if e[k]>0})}
load=[json.loads(l) for l in (OUT/'window-process-load.jsonl').read_text().splitlines()]
assert all(not x['competingGpuNames'] for x in load),'Competing workload recorded'
result={'sourceCommits':json.loads((OUT/'prepare.json').read_text())['sources'],
    'labels':{k:v['assessment'] for k,v in summaries.items()},
    'wallComparison':comparison,'monitoringOverhead':summaries['monitoring']['monitoringOverhead'],
    'monitoringGroups':summaries['monitoring']['groups'],'monitoringObserved':telemetry,
    'seek':summaries['seek']['groups'],'transparent':summaries['transparent']['groups'],
    'traceStages':summaries['trace-main']['stages']+summaries['trace-heavy']['stages'],
    'traceBytes':summaries['trace-main']['bytes']+summaries['trace-heavy']['bytes'],
    'traceComparisons':{label:json.loads((OUT/'runs'/('trace-'+label)/'trace-comparison.json').read_text()) for label in ['main','heavy']},
    'loadObservation':{'samples':len(load),'firstUtc':load[0]['utc'],'lastUtc':load[-1]['utc'],'knownCompetingSamples':0,
        'scope':'30-second process-name/CPU snapshots and per-label preflight; ordinary desktop remains active. Not continuous proof of exclusive hardware or fixed clocks.'}}
result['sourceCommits']={k:v['commit'] for k,v in result['sourceCommits'].items()}
DEST.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
rows=['| 场景 | 后端 | 旧 median / P95 / max ms | 新 median / P95 / max ms | median 降幅 |','| --- | --- | ---: | ---: | ---: |']
for r in comparison:
    fmt=lambda x:' / '.join(f'{x[k]:.3f}' for k in ['median','p95','max'])
    rows.append(f"| {r['scenario']} | {r['backend']} | {fmt(r['old']['frameWallMs'])} | {fmt(r['new']['frameWallMs'])} | {r['medianReductionPercent']:.2f}% |")
(OUT/'comparison-table.md').write_text('\n'.join(rows)+'\n')
print('\n'.join(rows))
