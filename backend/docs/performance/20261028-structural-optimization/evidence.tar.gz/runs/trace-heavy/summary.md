| 场景 | 后端 | 执行体 | 监控模式 | 帧数 | 单帧中位数 ms | P95 ms | 新会话创建中位数 ms | 首帧中位数 ms |
|---|---|---|---|---:|---:|---:|---:|---:|
| combined | cpu | new-instrumented | off | 8 | 3233.332 | 3400.386 | 1205.079 | 3921.570 |
| combined | cpu | old-instrumented | off | 8 | 5092.856 | 5321.374 | 1215.901 | 5617.544 |
| combined | vulkan | new-instrumented | off | 8 | 325.067 | 341.332 | 1132.706 | 744.018 |
| combined | vulkan | old-instrumented | off | 8 | 1243.559 | 1282.759 | 1131.036 | 1731.480 |
| material | cpu | new-instrumented | off | 8 | 2917.168 | 3134.662 | 234.903 | 3009.062 |
| material | cpu | old-instrumented | off | 8 | 4489.169 | 4673.757 | 194.794 | 4535.102 |
| material | vulkan | new-instrumented | off | 8 | 299.707 | 314.145 | 387.556 | 791.203 |
| material | vulkan | old-instrumented | off | 8 | 1202.401 | 1243.177 | 254.507 | 1611.365 |
