| 场景 | 后端 | 执行体 | 帧数 | 单帧中位数 ms | P95 ms | 新会话创建中位数 ms | 首帧中位数 ms |
|---|---|---|---:|---:|---:|---:|---:|
| csharp | cpu | baseline | 120 | 4.854 | 9.275 | 1080.017 | 214.885 |
| csharp | cpu | instrumented | 120 | 3.878 | 6.735 | 1016.987 | 210.681 |
| csharp | vulkan | baseline | 120 | 6.440 | 11.329 | 1190.745 | 207.029 |
| csharp | vulkan | instrumented | 120 | 5.405 | 7.967 | 1070.508 | 199.294 |
| graph | cpu | baseline | 120 | 457.528 | 540.612 | 444.277 | 754.066 |
| graph | cpu | instrumented | 120 | 451.230 | 527.560 | 361.123 | 709.511 |
| graph | vulkan | baseline | 120 | 176.428 | 227.412 | 397.786 | 500.133 |
| graph | vulkan | instrumented | 120 | 174.560 | 214.440 | 412.143 | 529.558 |
| lyrics | cpu | baseline | 120 | 1.091 | 2.833 | 10.731 | 146.249 |
| lyrics | cpu | instrumented | 120 | 1.129 | 1.585 | 9.369 | 109.416 |
| lyrics | vulkan | baseline | 120 | 3.437 | 4.322 | 89.304 | 177.067 |
| lyrics | vulkan | instrumented | 120 | 2.914 | 3.976 | 72.169 | 132.369 |
| particle | cpu | baseline | 120 | 8.515 | 13.857 | 1359.636 | 318.339 |
| particle | cpu | instrumented | 120 | 7.186 | 10.607 | 1016.937 | 291.832 |
| particle | vulkan | baseline | 120 | 9.979 | 13.887 | 1170.461 | 306.074 |
| particle | vulkan | instrumented | 120 | 11.793 | 14.815 | 1801.858 | 414.648 |
