| 场景 | 后端 | 执行体 | 监控模式 | 帧数 | 单帧中位数 ms | P95 ms | 新会话创建中位数 ms | 首帧中位数 ms |
|---|---|---|---|---:|---:|---:|---:|---:|
| combined | cpu | new | detailed | 24 | 3213.793 | 3645.036 | 1983.257 | 3713.973 |
| combined | cpu | new | off | 24 | 3261.502 | 3540.863 | 1197.377 | 4184.410 |
| combined | cpu | new | summary | 24 | 3304.211 | 3583.519 | 1234.732 | 3983.121 |
| combined | vulkan | new | detailed | 24 | 364.493 | 432.131 | 1218.542 | 837.723 |
| combined | vulkan | new | off | 24 | 327.647 | 416.977 | 1191.510 | 741.899 |
| combined | vulkan | new | summary | 24 | 362.700 | 424.016 | 1332.190 | 797.910 |
| csharp | cpu | new | detailed | 24 | 4.296 | 5.625 | 1095.177 | 240.652 |
| csharp | cpu | new | off | 24 | 4.106 | 4.766 | 1121.777 | 230.269 |
| csharp | cpu | new | summary | 24 | 4.631 | 6.843 | 1139.843 | 230.598 |
| csharp | vulkan | new | detailed | 24 | 5.694 | 8.026 | 1545.387 | 197.737 |
| csharp | vulkan | new | off | 24 | 5.389 | 6.871 | 1187.213 | 211.536 |
| csharp | vulkan | new | summary | 24 | 5.935 | 7.482 | 1348.917 | 195.106 |
| lyrics | cpu | new | detailed | 24 | 1.273 | 2.018 | 10.235 | 138.595 |
| lyrics | cpu | new | off | 24 | 1.038 | 1.903 | 13.701 | 131.854 |
| lyrics | cpu | new | summary | 24 | 1.589 | 1.906 | 14.030 | 201.875 |
| lyrics | vulkan | new | detailed | 24 | 3.641 | 4.788 | 91.771 | 190.376 |
| lyrics | vulkan | new | off | 24 | 2.870 | 4.617 | 71.195 | 124.795 |
| lyrics | vulkan | new | summary | 24 | 2.770 | 4.729 | 64.717 | 124.413 |
