"""Create and verify the bounded research archive; does not build or render."""
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile
import tempfile

root = Path(__file__).resolve().parent
destination = root.parents[1] / 'docs/performance/20261028-structural-research'
destination.mkdir(parents=True, exist_ok=True)
def sha(data):
    return hashlib.sha256(data).hexdigest()
def dump(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n')

files = [p for p in root.iterdir() if p.is_file() and p.suffix in ['.json', '.py', '.log', '.patch']]
for directory in ['runs', 'color-runs', 'origin-runs', 'runtime-runs', 'followup-runs', 'historical-traces', 'upstream']:
    files.extend(p for p in (root / directory).rglob('*') if p.is_file() and p.suffix != '.html')
files.extend([root / 'ReadbackProbe/Program.cs', root / 'ReadbackProbe/ReadbackProbe.csproj'])
files = sorted(files)
patterns = [rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',
            rb'github_pat_[A-Za-z0-9_]{30,}', rb'gh[pousr]_[A-Za-z0-9]{30,}',
            rb'xox[baprs]-[A-Za-z0-9-]{20,}', rb'Bearer [A-Za-z0-9._~-]{24,}',
            rb'sk-proj-[A-Za-z0-9_-]{30,}']
entries = []
with (destination / 'evidence.tar.gz').open('wb') as output:
    with gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for path in files:
                name = path.relative_to(root).as_posix()
                data = path.read_bytes()
                assert not any(re.search(pattern, data) for pattern in patterns), ('credential-pattern', name)
                entries.append({'path': name, 'bytes': len(data), 'sha256': sha(data)})
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(data), 0o644, 0
                archive.addfile(info, io.BytesIO(data))

blob = (destination / 'evidence.tar.gz').read_bytes()
index = {'schema': 'gpu-structural-research-evidence-v1',
         'sourceCommit': '61ee27ef069c1d7126e68a3bfe0e6c6d8391d3bd',
         'scope': 'Isolated research only; includes negative TopLeft evidence and separately identified historical traces.',
         'archive': {'path': 'evidence.tar.gz', 'bytes': len(blob), 'sha256': sha(blob)}, 'files': entries}
dump(destination / 'evidence-index.json', index)

with tempfile.TemporaryDirectory(prefix='mako-gpu-research-verify-') as temporary:
    extracted = Path(temporary)
    with tarfile.open(destination / 'evidence.tar.gz', 'r:gz') as archive:
        archive.extractall(extracted, filter='data')
    for row in entries:
        assert sha((extracted / row['path']).read_bytes()) == row['sha256']
    expected = (extracted / 'assessment.json').read_bytes()
    subprocess.run(['python3', str(extracted / 'analyze.py')], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    assert (extracted / 'assessment.json').read_bytes() == expected

assessment = json.loads((root / 'assessment.json').read_text())
audit = json.loads((root / 'workspace-audit.json').read_text())
compact = {'scope': assessment['scope'], 'sourceCommit': audit['sourceCommit'],
           'micro': assessment['micro'], 'pairedRuntime': assessment['pairedRuntime'],
           'historicalTraceReanalysis': assessment['historicalTraceReanalysis'],
           'runtimeVerification': audit['runtime'], 'microVerification': audit['micro'],
           'selectedInputsVerified': audit['selectedInputsVerified'],
           'observedExitZeroAndAbsentProcesses': len(audit['observedProcesses']),
           'archive': index['archive']}
dump(destination / 'compact-research-summary.json', compact)
dump(destination / 'archive-verification.json', {
    'verifiedUtc': datetime.now(timezone.utc).isoformat(),
    'archiveSha256': sha(blob), 'extractedFilesVerified': len(entries),
    'assessmentByteIdenticalAfterOfflineRecompute': True,
    'credentialPatternScan': {'files': len(entries), 'matches': 0,
                              'scope': 'Private-key headers, GitHub/Slack/OpenAI token patterns and long Bearer values; not a proof of absence of every possible credential.'},
    'productionBuildOrRenderPerformed': False,
})
print(json.dumps({'archive': index['archive'], 'files': len(entries), 'offlineRecompute': 'byte-identical'}, indent=2))
