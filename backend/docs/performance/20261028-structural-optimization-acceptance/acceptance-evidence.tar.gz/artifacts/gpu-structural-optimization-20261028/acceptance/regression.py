from pathlib import Path
import datetime, fcntl, hashlib, json, os, signal, subprocess, time
import xml.etree.ElementTree as ET

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent / 'regression-final1'
OUT.mkdir(exist_ok=False)
NS = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
records = []
env = os.environ.copy()
env.update(MSBUILDDISABLENODEREUSE='1', DOTNET_CLI_TELEMETRY_OPTOUT='1',
           HTTP_PROXY='http://127.0.0.1:7897', HTTPS_PROXY='http://127.0.0.1:7897',
           VK_DRIVER_FILES='/usr/share/vulkan/icd.d/radeon_icd.json',
           VK_ICD_FILENAMES='/usr/share/vulkan/icd.d/radeon_icd.json')
for key in list(env):
    if key.startswith('MAKO_PERFORMANCE') or key == 'MAKO_GPU_SMOKE': env.pop(key)
source = subprocess.check_output(['git','rev-parse','HEAD'], text=True).strip()
paths = subprocess.check_output(['git','ls-files','src','tests','samples','Directory.Build.props','Directory.Build.targets','global.json'], text=True).splitlines()
def fingerprints(): return {p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in paths}
original = fingerprints()
def stamp(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save():
    (OUT/'commands.json').write_text(json.dumps({'sourceCommit':source,'commands':records},indent=2)+'\n')
def run(name,args,backend='cpu',smoke=False):
    current=env.copy();current['MAKO_RENDER_BACKEND']=backend
    if smoke:current['MAKO_GPU_SMOKE']='1'
    if args[1]=='test':args += ['--logger','trx;LogFileName='+name+'.trx','--results-directory',str(OUT)]
    item={'name':name,'command':args,'startedUtc':stamp(),'backend':backend,'gpuSmoke':smoke}
    records.append(item);save();print('START '+name,flush=True)
    start=time.monotonic()
    with (OUT/(name+'.log')).open('w') as log:
        process=subprocess.Popen(args,env=current,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        item['pid']=process.pid;save()
        try:code=process.wait(timeout=2400)
        except BaseException:
            os.killpg(process.pid,signal.SIGTERM)
            process.wait(timeout=30)
            raise
    item.update(exitCode=code,elapsedSeconds=time.monotonic()-start,completedUtc=stamp())
    if args[1]=='test':
        trx=OUT/(name+'.trx')
        if trx.exists():
            tree=ET.parse(trx)
            item['counters']={k:int(v) for k,v in tree.find('.//t:Counters',NS).attrib.items()}
            item['failedTests']=[x.attrib['testName'] for x in tree.findall('.//t:UnitTestResult',NS) if x.attrib['outcome']=='Failed']
    if args[1]=='build':
        contents=(OUT/(name+'.log')).read_text()
        item['zeroWarningsAndErrors']='0 Warning(s)' in contents and '0 Error(s)' in contents
    save();print('DONE '+name+' '+str(code)+' '+json.dumps(item.get('counters',{})),flush=True)
    assert code==0,item
    if args[1]=='test': assert item.get('counters',{}).get('executed',0)>0 and item['counters']['failed']==0,item
    if args[1]=='build':assert item['zeroWarningsAndErrors'],item
def test(project,filter=None):
    args=['dotnet','test',f'tests/MakoKaraGenerator.{project}.Tests/MakoKaraGenerator.{project}.Tests.csproj','--no-build','--no-restore','-m:1','/nodeReuse:false']
    if filter:args+=['--filter',filter]
    return args
with open('/tmp/mkg-performance-optimization-dotnet.lock','a') as lock:
    fcntl.flock(lock,fcntl.LOCK_EX)
    assert fingerprints()==original,'source changed while waiting for lock'
    (OUT/'inputs.json').write_text(json.dumps(original,indent=2)+'\n')
    run('solution-debug-build',['dotnet','build','MakoKaraGenerator.slnx','--no-restore','-c','Debug','-m:1','/p:UseSharedCompilation=false','/nodeReuse:false'])
    for backend in ('cpu','vulkan'):
        for project in ('Rendering','Runtime.Hosting','Backend.Rendering','Backend.Rendering.Skia'):
            run(backend+'-'+project,test(project),backend)
    for project in ('Scripting','Backend.Worker','Backend.Server'):
        run(project,test(project))
    run('Backend.Hosting-focused',test('Backend.Hosting','FullyQualifiedName~WorkerProcessProxy|FullyQualifiedName~WorkerTelemetryDrain'))
    run('explicit-vulkan',test('Rendering','FullyQualifiedName~VulkanOwnedImageReadbackTests|FullyQualifiedName~VulkanRenderDeviceSmokeTests|FullyQualifiedName~MaterialAuthorGraphCacheTests|FullyQualifiedName~SkiaPerformanceTelemetryTests'),'vulkan',True)
    assert fingerprints()==original,'source drift during acceptance'
    (OUT/'summary.json').write_text(json.dumps({'passed':True,'sourceCommit':source,'sourceStable':True,'commands':len(records),'testRuns':{r['name']:r['counters'] for r in records if 'counters' in r},'completedUtc':stamp()},indent=2)+'\n')
